<?php
    class Dnk_Certificates_Model_Mysql4_Certificates_Collection extends Mage_Core_Model_Mysql4_Collection_Abstract
    {

		public function _construct(){
			$this->_init("certificates/certificates");
		}

		

    }
	 