<?php

class Dnk_Sms_Helper_Data extends Mage_Core_Helper_Abstract
{

}