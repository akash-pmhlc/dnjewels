<?php

class Dnk_Rates_Model_Rates extends Mage_Core_Model_Abstract
{
    protected function _construct(){

       $this->_init("rates/rates");

    }

}
	 