<?php  

class Dnk_Shapes_Block_Adminhtml_Shapesbackend extends Mage_Adminhtml_Block_Template {

}