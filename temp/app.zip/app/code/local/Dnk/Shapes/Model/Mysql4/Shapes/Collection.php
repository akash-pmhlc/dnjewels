<?php
    class Dnk_Shapes_Model_Mysql4_Shapes_Collection extends Mage_Core_Model_Mysql4_Collection_Abstract
    {

		public function _construct(){
			$this->_init("shapes/shapes");
		}

		

    }
	 