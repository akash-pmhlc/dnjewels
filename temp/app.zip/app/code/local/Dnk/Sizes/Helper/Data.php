<?php
class Dnk_Sizes_Helper_Data extends Mage_Core_Helper_Abstract
{
}
	 