<?php
    class Dnk_Sizes_Model_Mysql4_Sizes_Collection extends Mage_Core_Model_Mysql4_Collection_Abstract
    {

		public function _construct(){
			$this->_init("sizes/sizes");
		}

		

    }
	 